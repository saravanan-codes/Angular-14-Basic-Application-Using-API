export const environment = {
production:false,
baseApiUrl:'https://localhost:7056/'
};
